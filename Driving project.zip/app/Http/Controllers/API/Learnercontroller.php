<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\TwilioVerifyService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Kreait\Firebase\Auth as FirebaseAuth;

class Learnercontroller extends Controller
{
    public function index()
    {
        $learners = User::where('user_type', 'learner')->get();

        return response()->json($learners);
    }


    public function firebaseLogin(Request $request, FirebaseAuth $firebaseAuth)
    {
        $request->validate([
            'idToken' => 'required|string',
        ]);

        try {
            // Verify the token with Firebase
            $verifiedIdToken = $firebaseAuth->verifyIdToken($request->idToken);

            // Get Firebase UID (unique identifier for the user)
            $firebaseUid = $verifiedIdToken->claims()->get('sub');

            // Get phone number (should be available for phone auth)
            $phoneNumber = $verifiedIdToken->claims()->get('phone_number');

            // Get email if available
            $email = $verifiedIdToken->claims()->get('email');

            if (!$phoneNumber && !$email) {
                return response()->json([
                    'error' => 'Neither phone number nor email found in the ID token.'
                ], 400);
            }

            // Find or create the user in your local database
            $user = User::firstOrCreate(
                ['firebase_uid' => $firebaseUid],
                [
                    'phone' => $phoneNumber,
                    'email' => $email ?? null,
                    'name' => 'Unknown',
                    'password' => bcrypt(Str::random(32)), // Random password as it's not used
                    'user_type' => 'learner',
                ]
            );

            // Issue Sanctum token for API authentication
            $token = $user->createToken('auth_token')->plainTextToken;

            return response()->json([
                'message' => 'Logged in successfully',
                'token' => $token,
                'user' => $user,
            ]);
        } catch (\Kreait\Firebase\Exception\Auth\FailedToVerifyToken $e) {
            return response()->json(['error' => 'Invalid ID token.'], 401);
        } catch (\Throwable $e) {
            return response()->json(['error' => 'Login failed: ' . $e->getMessage()], 500);
        }
    }
}
