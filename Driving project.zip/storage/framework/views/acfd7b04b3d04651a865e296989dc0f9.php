

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageTitle'); ?>
    <?php echo e($pageTitle); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('dashboard.layouts.common._partial.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="card">
    <form action="<?php echo e(route('admin.codes.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="number_of_codes">Number of Codes to Generate:</label>
            <input type="number" name="number_of_codes" id="number_of_codes" min="1" required>
        </div>
        <button type="submit" class=" btn btn-primary my-5">Generate Codes</button>
    </form>

    <?php if(session('success')): ?>
        <p style="color: green;"><?php echo e(session('success')); ?></p>
    <?php endif; ?>
    </div>

   
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    




<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\backup\videoplatform\resources\views/dashboard/Admin/codes/create.blade.php ENDPATH**/ ?>