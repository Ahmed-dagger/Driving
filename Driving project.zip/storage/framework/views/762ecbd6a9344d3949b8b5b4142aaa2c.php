<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('pageTitle', $pageTitle); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid SubHeaderAbout pb-4">
    <div class="container ">
        <div class="row g-3">
            <div class="col-sm-5">
                <div class="container d-flex my-4">
                    <a href="<?php echo e(route('site.home')); ?>" class="text-decoration-none">
                        <h4 class="text-secondary mr-2">Home </h4>
                    </a>
                    <h4 class="text-secondary mr-2"> / </h4>
                    <a href="<?php echo e(route('site.About')); ?>" class="text-decoration-none">
                        <h4 class="text-secondary"> About </h4>
                    </a>
                </div>
                <div class="container my-4">
                    <h3>
                        You can reach out all Knowledge <br> with fair fees and <br> keep going on your passion.
                    </h3>

                </div>

            </div>

        </div>

        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <img class="SubHeaderAboutImg mb-4" src="<?php echo e(asset('dashboard/assets/img/SubHeaderAbout.png')); ?>" alt="">

                </div>


            </div>

        </div>

    </div>

</div>

<div class="container-fluid justify-content-center py-2 align-items-center InfoCounterAbout">
    <div class="row my-5 justify-content-center text-center align-items-center">
        <div class="col-sm-2">

        </div>
        <div class=" col-sm-2 justify-content-center my-5 text-center">
            <div class="container justify-content-center text-center">
                <img src="<?php echo e(asset('dashboard/assets/img/coursesIcon.png')); ?>" class="InfoCounterAbouticon" alt="">
                <h5 class="my-4 text-center text-danger">Courses</h5>
                <h5 class="text-danger text-center counter" data-count="<?php echo e($courses); ?>">0</h5>


            </div>
        </div>
        <div class=" col-sm-2 justify-content-center mx-5 my-5 text-center">
            <div class="container justify-content-center text-center">
                <img src="<?php echo e(asset('dashboard/assets/img/studentsbrainicon.png')); ?>" alt="" class="InfoCounterAbouticon">
                <h5 class="my-4 text-center text-danger">Academies</h5>
                <h5 class="text-danger text-center counter" data-count="<?php echo e($academies); ?>">0</h5>

            </div>
        </div>
        <div class=" col-sm-2 justify-content-center my-5 text-center">
            <div class="container justify-content-center text-center">
                <img src="<?php echo e(asset('dashboard/assets/img/tutorsicon.png')); ?>" alt="" class="InfoCounterAbouticon">
                <h5 class="my-4 text-center text-danger">Tutors</h5>
                <h4 class="text-danger text-center counter" data-count="<?php echo e($teachers); ?>">0</h4>

            </div>
        </div>

        <div class="col-sm-2">

        </div>

    </div>

</div>







<div class="container-fluid text-light my-5 py-5 sectionOfvideotrailer align-items-center">
    <div class="row my-5 py-3 justify-content-between align-items-center">
        <div class="col-sm-6 px-5 my-5 py-2 justify-content-center text-center align-items-center">
            <h3 style="font-weight: 700; font-size: 35px;">Life Improvements</h3>
            <p style="font-size: 25px;">By learning from <br> <span class="text-danger">Subul Elmaharat</span></p>
        </div>
        <div class="col-sm-6 justify-content-center text-center">
            <button class="VideoButton">
                <img width="50" height="50" src="https://img.icons8.com/ios/128/ffffff/circled-play--v1.png"
                    alt="circled-play--v1" />
                Watch the <br> Introduction</button>

        </div>

    </div>

</div>

    <?php $__env->startPush('js'); ?>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.includes.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\newPLatform\resources\views/frontend/About.blade.php ENDPATH**/ ?>