        <!--end::Authentication - Sign-in-->
    </div>
    <!--end::Main-->
    <script>var hostUrl = "dashboard/assets/";</script>
    <!--begin::Javascript-->
    <!--begin::Global Javascript Bundle(used by all pages)-->
    <script src="<?php echo e(asset("dashboard/assets/plugins/global/plugins.bundle.js")); ?>"></script>
    <script src="<?php echo e(asset("dashboard/assets/js/scripts.bundle.js")); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
</body>
<!--end::Body-->
</html>
<?php /**PATH D:\Driving project\resources\views/dashboard/layouts/common/includes/login/_tpl_end.blade.php ENDPATH**/ ?>