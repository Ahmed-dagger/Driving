

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageTitle'); ?>
    <?php echo e($pageTitle); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('dashboard.layouts.common._partial.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card">
        <form class="form" method="POST" action="<?php echo e(route('admin.academics.update',$academic->id)); ?>">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="form-group">
                    <label>الاسم:</label>
                    <input name="name" type="text" class="form-control form-control-solid" placeholder="Enter full name"
                        value="<?php echo e(old('name', isset($academic) ? $academic->name : '')); ?>" />
                    <span class="form-text text-muted">Please enter your full name</span>
                </div>
                <div class="form-group">
                    <label>البريد الالكتروني:</label>
                    <input name="email" type="email" class="form-control form-control-solid" placeholder="Enter email"
                    value="<?php echo e(old('email', isset($academic) ? $academic->email : '')); ?>" />
                    <span class="form-text text-muted">We'll never share your email with anyone else</span>
                </div>
                <div class="form-group">
                    <label>رقم الهاتف:</label>
                    <input name="phone" type="text" class="form-control form-control-solid" placeholder="Enter phone"
                    value="<?php echo e(old('phone', isset($academic) ? $academic->phone : '')); ?>"  />
                    <span class="form-text text-muted">Please enter your phone number</span>
                </div>
                <div class="form-group">
                    <label>كلمة السر:</label>
                    <input name="password" type="password" class="form-control form-control-solid"
                        placeholder="Enter password" />
                    <span class="form-text text-muted">Please enter your password</span>
                </div>
                <div class="form-group">
                    <label>تأكيد كلمة السر:</label>
                    <input name="password_confirmation" type="password" class="form-control form-control-solid"
                        placeholder="Confirm password" />
                    <span class="form-text text-muted">Please confirm your password</span>
                </div>
                <div class="form-group">
                    <label>الحالة:</label>
                    <div class="checkbox-list">
                        <label class="checkbox">
                            <input type="radio" name="status" value="active"
                            <?php echo e(old('status', isset($academic->status))  ? 'checked' : ''); ?> />
                            <span></span>
                            Active
                        </label>
                        <label class="checkbox">
                            <input type="radio" name="status" value="inactive"
                            <?php echo e(old('status', isset($academic->status))  ? 'checked' : ''); ?> />
                            <span></span>
                            Inactive
                        </label>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-primary mr-2">تأكيد</button>
                <button type="reset" class="btn btn-secondary">إلغاء</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <link href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet">
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\newPLatform\resources\views/dashboard/Admin/academics/edit.blade.php ENDPATH**/ ?>