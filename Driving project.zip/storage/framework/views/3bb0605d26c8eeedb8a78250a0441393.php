<?php echo $__env->make('dashboard.layouts.common.includes.login._tpl_start', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('dashboard.layouts.common.includes.login._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('dashboard.layouts.common.includes.login._tpl_end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\backup\videoplatform\resources\views/dashboard/layouts/login.blade.php ENDPATH**/ ?>