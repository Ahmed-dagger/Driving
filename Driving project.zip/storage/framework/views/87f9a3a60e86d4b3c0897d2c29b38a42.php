<div class="d-flex">


    <?php if($admin->deleted_at == null): ?>
        <form id="delete-form-<?php echo e($admin->id); ?>" action="<?php echo e(route('admin.destroy', $admin->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>

            <button class="btn btn-danger mx-1"><?php echo e(trans('dashboard/general.delete')); ?></button>


        </form>
    <?php else: ?>
        <form action="<?php echo e(route('admin.restore',$admin->id)); ?>" method="post">
            <?php echo csrf_field(); ?>

            <button class="btn btn-danger mx-1"><?php echo e(trans('dashboard/general.restore')); ?></button>


        </form>
    <?php endif; ?>

    <form action="">
        <button class="btn btn-info"><?php echo e(trans('dashboard/general.update')); ?></button>

    </form>

</div>


    <script>
        function deleteAdmin(id) {
            if (confirm("Are you sure you want to delete this admin?")) {
                document.getElementById('delete-form-' + id).submit();
            }
        }
    </script>

<?php /**PATH E:\platform\newPlatform\resources\views/dashboard/admin/admins/btn/actions.blade.php ENDPATH**/ ?>