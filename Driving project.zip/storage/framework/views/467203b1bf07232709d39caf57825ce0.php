<div class="d-flex">


    <!-- <?php if($code-> deleted_at == null): ?>
        <form id="delete-form-<?php echo e($code->id); ?>" action="<?php echo e(route('admin.videos.destroy', $code->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="btn btn-danger mx-1  btn-sm"><?php echo e(trans('dashboard/general.delete')); ?></button>
        </form>
    <?php else: ?>
        <form action="<?php echo e(route('admin.restore',$code->id)); ?>" method="post">
            <?php echo csrf_field(); ?>

            <button class="btn btn-danger mx-1 btn-sm"><?php echo e(trans('dashboard/general.restore')); ?></button>


        </form>
    <?php endif; ?> -->

        <a href="" class="btn btn-info btn-sm" style="margin-left: 5px; justify-content: center; align-items: center; display: flex;"><?php echo e(trans('dashboard/general.update')); ?></a>
        <button class="btn btn-danger mx-1  btn-sm"><?php echo e(trans('dashboard/general.delete')); ?></button>

</div>


    <script>
        function deleteAdmin(id) {
            if (confirm("Are you sure you want to delete this admin?")) {
                document.getElementById('delete-form-' + id).submit();
            }
        }
    </script>

<?php /**PATH D:\backup\videoplatform\resources\views/dashboard/admin/codes/btn/actions.blade.php ENDPATH**/ ?>