


    <script>
        function deleteAdmin(id) {
            if (confirm("Are you sure you want to delete this admin?")) {
                document.getElementById('delete-form-' + id).submit();
            }
        }
    </script>

<?php /**PATH D:\Driving project\resources\views/dashboard/admin/codes/btn/actions.blade.php ENDPATH**/ ?>