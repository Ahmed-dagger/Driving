<div class="menu-item">
    <div class="pb-2 menu-content">
        <span class="menu-section text-muted text-uppercase fs-8 ls-1"><?php echo e(check_guard()->name); ?> Dashboard</span>
    </div>
</div>


<div class="menu-item">
    <a class="menu-link <?php echo e(request()->routeIS('admin.settings') ? 'active' : ''); ?>" href="<?php echo e(route('admin.settings')); ?>">
        <span class="menu-icon">
            <i class="bi bi-grid fs-3"></i>
        </span>
        <span class="menu-title"><?php echo e(trans('dashboard/admin.settings')); ?></span>
    </a>
</div>

<div class="menu-item">
    <a class="menu-link <?php echo e(request()->routeIS('admin.codes.index') ? 'active' : ''); ?>" href="<?php echo e(route('admin.codes.index')); ?>">
        <span class="menu-icon">
            <i class="bi bi-grid fs-3"></i>
        </span>
        <span class="menu-title"><?php echo e(trans('dashboard/admin.codes')); ?></span>
    </a>
</div>

<div class="menu-item">
    <a class="menu-link <?php echo e(request()->routeIS('admin.learners.index') ? 'active' : ''); ?>" href="<?php echo e(route('admin.learners.index')); ?>">
        <span class="menu-icon">
            <i class="bi bi-grid fs-3"></i>
        </span>
        <span class="menu-title"><?php echo e(trans('dashboard/admin.learners')); ?></span>
    </a>
</div>

<div class="menu-item">
    <a class="menu-link <?php echo e(request()->routeIS('admin.instructors.index') ? 'active' : ''); ?>" href="<?php echo e(route('admin.instructors.index')); ?>">
        <span class="menu-icon">
            <i class="bi bi-grid fs-3"></i>
        </span>
        <span class="menu-title"><?php echo e(trans('dashboard/admin.instructors')); ?></span>
    </a>
</div>

<div class="menu-item">
    <a class="menu-link <?php echo e(request()->routeIS('admin.packages.index') ? 'active' : ''); ?>" href="<?php echo e(route('admin.packages.index')); ?>">
        <span class="menu-icon">
            <i class="bi bi-grid fs-3"></i>
        </span>
        <span class="menu-title"><?php echo e(trans('dashboard/admin.packages')); ?></span>
    </a>
</div>
<?php /**PATH D:\Driving project\resources\views/dashboard/layouts/common/includes/sidebars/_admin.blade.php ENDPATH**/ ?>