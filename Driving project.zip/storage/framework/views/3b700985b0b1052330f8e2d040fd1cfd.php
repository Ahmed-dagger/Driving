<header>
    <!-- Top Header -->
    
    <!-- Main Header -->
    <div class="text-center pt-5">
        <h1 class="text-center text-white pt-4">Welcome to our platform</h1>
    </div>
</header>
<?php /**PATH D:\backup\videoplatform\resources\views/frontend/includes/common/_header.blade.php ENDPATH**/ ?>