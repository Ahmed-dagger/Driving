<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('pageTitle', $pageTitle); ?>

<?php $__env->startSection('content'); ?>


<div class="container my-5">
    <div class="row justify-content-center text-center my-5">
<div class="container justify-content-center text-center">
    </div>
    </div>
</div>


    <?php $__env->startPush('js'); ?>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.includes.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Driving project\resources\views/frontend/home.blade.php ENDPATH**/ ?>