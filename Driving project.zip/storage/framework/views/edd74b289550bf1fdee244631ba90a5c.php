
<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('pageTitle', $pageTitle); ?>

<?php $__env->startSection('content'); ?>

    <!--
            Source Code:  https://github.com/PrisonBreak8/CODEPEN/tree/main/responsive-video
            -->

    <div class="container-fluid justify-content-center align-items-center SubHeader"
        style="background-image: url(<?php echo e($course->getFirstMediaUrl('courses')); ?>)">
        <div class="container align-items-center justify-content-center">
            <div class="row justify-content-center align-items-center">
                <div class="container d-flex  pt-5 mt-3">
                    <a class="text-decoration-none" href="<?php echo e(route('site.home')); ?>">
                        <h5 class="text-light pr-1">Home </h5>
                    </a>
                    <h6 class="text-danger d-flex">🔴</h6>
                    <a href="<?php echo e(route('site.courses')); ?>" class="text-decoration-none">
                        <h5 class="text-light pl-1">Courses</h5>
                    </a>

                    <h6 class="text-danger d-flex">🔴</h6>
                    <a href="#" class="text-decoration-none">
                        <h5 class="text-light pl-1"><?php echo e($course->name); ?></h5>
                    </a>

                </div>

                <div class="container d-flex mt-3">
                    
                    <p class="text-danger pt-2 ml-2"><?php echo e($category->name); ?></p>

                </div>

                <div class="container mt-3">
                    <h3 class=" text-light "><?php echo e($course->name); ?></h3>
                </div>

                <div class="container d-flex mt-3 mb-5">
                    <img src="../img/Bannerwoman.png" width="30" class="rounded-circle" alt="">
                    <h6 class="text-light pt-2 pl-3"><?php echo e($teacher->name); ?></h6>
                    <h6 class="text-light pt-2 pl-3">|</h6>
                    <h6 class="pt-2 pl-3 text-light">Released At: <?php echo e($course->created_at); ?></h6>
                </div>

                <div class="container d-flex mb-5">
                    <img src="../img/Bannerwoman.png" width="30" class="rounded-circle" alt="">
                    <h6 class="text-light pt-2 pl-3 font-weight-bold"><span class="text-danger">This course Talks About: </span><?php echo e($course-> desc); ?></h6>
                    
                </div>
                
            </div>
        </div>
    </div>

    <div class="container videoplaylist-container">



        <div class="main-video-container">
            <video class="main-video" src="img/vid-1.mp4" loop controls></video>
            <h3 class="main-video__title">house flood animation</h3>
            <p class="main-video__desc">Description:</p>
        </div>

        <div class="video-list-container">

            <h3 class="font-weight-bold my-4">Course Content</h3>
            <div class="accordion" id="accordionExample">

                <?php $__currentLoopData = $course->playlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $playlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="heading<?php echo e($playlist->id); ?>">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                data-bs-target="#collapse<?php echo e($playlist->id); ?>" aria-expanded="true"
                                aria-controls="collapse<?php echo e($playlist->id); ?>">
                                <?php echo e($playlist->name); ?>

                            </button>
                        </h2>
                        <div id="collapse<?php echo e($playlist->id); ?>" class="accordion-collapse collapse show"
                            aria-labelledby="heading<?php echo e($playlist->id); ?>" data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <?php $__currentLoopData = $playlist->videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    

                                        <div class="list">
                                            <video class="list__video" src="img/vid-1.mp4"></video>
                                            <h3 class="list__title"><?php echo e($video->title); ?></h3>
                                            <p class="list__desc" hidden> <span class="my-3 font-weight-bold">Description:</span>
                                                <br><?php echo e($video-> description); ?></p>
                                        </div>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                

            </div>

        </div>
    </div>


        <?php $__env->startPush('js'); ?>
        <script>
            let videoList = document.querySelectorAll(".video-list-container .list");
        
            // Function to set the first video in the main container on page load
            function setFirstVideo() {
                if (videoList.length > 0) {
                    // Select the first video element in the list
                    let firstVideo = videoList[0];
        
                    // Add the 'active' class to the first video
                    firstVideo.classList.add("active");
        
                    // Get the source, title, and description of the first video
                    let src = firstVideo.querySelector(".list__video").src;
                    let title = firstVideo.querySelector(".list__title").innerHTML;
                    let desc = firstVideo.querySelector(".list__desc").innerHTML;
        
                    // Set the main video container with the first video's details
                    document.querySelector(".main-video-container .main-video").src = src;
                    document.querySelector(".main-video-container .main-video").play();
        
                    document.querySelector(".main-video-container .main-video__title").innerHTML = title;
                    document.querySelector(".main-video-container .main-video__desc").innerHTML = desc;
                }
            }
        
            // Call the function to set the first video
            setFirstVideo();
        
            // Event listener for clicking on videos
            videoList.forEach((vid) => {
                vid.onclick = () => {
                    videoList.forEach((remove) => {
                        remove.classList.remove("active");
                    });
                    vid.classList.add("active");
        
                    let src = vid.querySelector(".list__video").src;
                    let title = vid.querySelector(".list__title").innerHTML;
                    let desc = vid.querySelector(".list__desc").innerHTML;
        
                    document.querySelector(".main-video-container .main-video").src = src;
                    document.querySelector(".main-video-container .main-video").play();
        
                    document.querySelector(".main-video-container .main-video__title").innerHTML = title;
                    document.querySelector(".main-video-container .main-video__desc").innerHTML = desc;
                };
            });
        </script>
        
            <?php $__env->stopPush(); ?>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.includes.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\newPLatform\resources\views/frontend/courseContent.blade.php ENDPATH**/ ?>