<footer>
    
</footer><?php /**PATH D:\backup\videoplatform\resources\views/frontend/includes/common/_footer.blade.php ENDPATH**/ ?>