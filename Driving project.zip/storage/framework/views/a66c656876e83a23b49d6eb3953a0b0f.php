
<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('pageTitle', $pageTitle); ?>

<?php $__env->startSection('content'); ?>
   

<?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="container">
    <video width="640" height="480" controls>
    <source src="<?php echo e(asset('storage/' . $video->path)); ?>" type="video/mp4">
    Your browser does not support the video tag.
</video>
    <h1 class="text-light"><?php echo e($video->name); ?></h1>
</div>
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.includes.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\videoplatform\resources\views/frontend/content.blade.php ENDPATH**/ ?>