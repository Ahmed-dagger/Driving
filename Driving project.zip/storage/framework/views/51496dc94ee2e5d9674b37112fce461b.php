<footer>
    
</footer><?php /**PATH D:\videoplatform\resources\views/frontend/includes/common/_footer.blade.php ENDPATH**/ ?>