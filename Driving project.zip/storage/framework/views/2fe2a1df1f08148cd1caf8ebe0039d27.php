<div class="d-flex">


    <?php if($playlist->deleted_at == null): ?>
        <button class="btn btn-danger mx-1" onclick="confirmDeleteAdmin(<?php echo e($playlist->id); ?>)"><?php echo e(trans('dashboard/general.delete')); ?></button>
        <form id="delete-form-<?php echo e($playlist->id); ?>" action="<?php echo e(route('admin.playlist.playlists.destroy', $playlist->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
        </form>
    <?php else: ?>
        <form action="<?php echo e(route('admin.restore',$playlist->id)); ?>" method="post">
            <?php echo csrf_field(); ?>

            <button class="btn btn-danger mx-1"><?php echo e(trans('dashboard/general.restore')); ?></button>


        </form>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.playlist.playlists.edit',$playlist->id)); ?>">
        <button class="btn btn-info"><?php echo e(trans('dashboard/general.update')); ?></button>

    </form>

</div>

<div class="modal fade" id="deleteAdminModal" tabindex="-1" aria-labelledby="deleteAdminModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteAdminModalLabel">Delete Admin</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Are you sure you want to delete this admin?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmDeleteAdminBtn">Delete</button>
            </div>
        </div>
    </div>
</div>


    <script>
             let selectedAdminId = null; // Variable to store the selected admin ID

// Function to trigger the delete confirmation modal
function confirmDeleteAdmin(adminId) {
    selectedAdminId = adminId; // Set the selected admin ID
    $('#deleteAdminModal').modal('show'); // Show the confirmation modal
}

// Handle the confirm delete button click
$('#confirmDeleteAdminBtn').on('click', function() {
    if (selectedAdminId) {
        // Submit the delete form for the selected admin
        document.getElementById('delete-form-' + selectedAdminId).submit();
        $('#deleteAdminModal').modal('hide'); // Hide the modal after submission
    }
});
    </script>

<?php /**PATH E:\newPLatform\resources\views/dashboard/admin/playlists/btn/actions.blade.php ENDPATH**/ ?>