<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageTitle'); ?>
    <?php echo e($pageTitle); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('dashboard.layouts.common._partial.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="kt_content_container" class="container-xxl">
        <div class="mb-5 card card-xxl-stretch mb-xl-8">
            <!--begin::Header-->
            <div class="pt-5 border-0 card-header">
                <h3 class="card-title align-items-start flex-column">
                    <span class="mb-1 card-label fw-bolder fs-3"><?php echo e($pageTitle); ?></span>
                    <span class="mt-1 text-muted fw-bold fs-7"><?php echo e($pageTitle); ?></span>
                    <div class="card-toolbar" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-trigger="hover" >
                    </div>
                </h3>
            </div>
            <div class="py-3 card-body">
                <!--begin::Table container-->
                <div id="jstree"></div>
                <!--end::Table container-->
            </div>
            <!--end::Header-->
            <!--begin::Body-->
            <!--begin::Body-->
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<script>
    $('#jstree').jstree({
    "core" : {

        'data' : <?php echo loadcategories(old('parent')); ?>,
        "themes" : {
        "variant" : "large"
      }

    },

    "checkbox" : {
      "keep_selected_style" : false
    },
    "plugins" : [ "wholerow", "checkbox" ]
  });
</script>




<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\platform\newPlatform\resources\views/dashboard/Admin/categories/index.blade.php ENDPATH**/ ?>