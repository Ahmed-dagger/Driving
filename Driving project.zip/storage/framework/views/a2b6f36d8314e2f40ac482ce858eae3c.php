

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageTitle'); ?>
    <?php echo e($pageTitle); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('dashboard.layouts.common._partial.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="card">
        <form class="form" method="POST" action="<?php echo e(route('admin.categories.update', $category->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?> 
        
            <div class="card-body">
                <!-- Name Fields -->
                <div class="form-group my-4">
                    <label><?php echo e(__('dashboard/forms.fullname')); ?></label>
                    <input name="name[ar]" type="text" class="form-control form-control-solid" placeholder="Enter Arabic name"
                    value="<?php echo e($category->translating('ar')->name ?? ''); ?>"/>
                    <input name="name[en]" type="text" class="form-control form-control-solid mt-2"
                        placeholder="Enter English name" value="<?php echo e($category->translating('en')->name ?? ''); ?>" />
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
        
                <!-- Description Fields -->
                <div class="form-group my-4">
                    <label><?php echo e(__('dashboard/forms.desc')); ?></label>
                    <input name="description[ar]" type="text" class="form-control form-control-solid"
                        placeholder="Enter Arabic description"
                        value="<?php echo e($category->translating('ar')->description ?? ''); ?>" />
                    <input name="description[en]" type="text" class="form-control form-control-solid mt-2"
                        placeholder="Enter English description"
                        value="<?php echo e($category->translating('en')->description ?? ''); ?>" />
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
        
                <!-- Parent Category Selection -->
                <div class="form-group">
                    <span><?php echo e(__('dashboard/forms.parent')); ?></span>
                    <div class="py-3 card-body">
                        <div id="jstree"></div> <!-- jstree -->
                    </div>
        
                    <input type="hidden" name="parent" id="parent" class="parent" value="<?php echo e($category->parent); ?>" />
                    <?php $__errorArgs = ['parent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        
            <div class="card-footer">
                <button type="submit" class="btn btn-primary mr-2"><?php echo e(__('dashboard/forms.Submit')); ?></button>
                <button type="reset" class="btn btn-secondary"><?php echo e(__('dashboard/forms.Reset')); ?></button>
            </div>
        </form>
    </div>


    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    



    <script>
        $('#jstree').jstree({
            "core": {

                'data': <?php echo loadcategories($category->parent , $category->id); ?>,
                "themes": {
                    "variant": "large"
                }

            },

            "checkbox": {
                "keep_selected_style": false
            },
            "plugins": ["wholerow"]
        });




        $('#jstree').on('changed.jstree',function(e, data) {

            var i, j, r = [];

            for (i = 0, j = data.selected.length; i < j; i++)
            {
                r.push(data.instance.get_node(data.selected[i]).id);
            }

            $('.parent').val(r.join(', '));


        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\newPLatform\resources\views/dashboard/Admin/categories/edit.blade.php ENDPATH**/ ?>