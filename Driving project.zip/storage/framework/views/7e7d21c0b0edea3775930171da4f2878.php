

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<script src="<?php echo e(asset('dashboard/assets/js/site/assets/js/burger-menu.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    AOS.init({

        offset: 200, // Offset (in px) from the original trigger point
        duration: 1000, // Duration of animation (in ms)
        easing: 'ease-in-out-sine', // Easing function
        delay: 100, // Delay before the animation starts (in ms)
        once: true, // Whether animation should happen only once - while scrolling down
        mirror: false, // Whether elements should animate out while scrolling past them
    });
</script>
<script>
   

    
</script>
<!-- JS scripts -->
<!--end::JS-->
<?php echo $__env->yieldPushContent('js'); ?>
</body>
<!--end::Body-->

</html>
<?php /**PATH D:\backup\videoplatform\resources\views/frontend/includes/common/_tpl_end.blade.php ENDPATH**/ ?>