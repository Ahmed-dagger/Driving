<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('pageTitle', $pageTitle); ?>

<?php $__env->startSection('content'); ?>


<div class="container my-5">
    <div class="row justify-content-center text-center my-5">
<div class="container justify-content-center text-center">
        <div class="cardcode">
            <a class="singup text-light">Enter The code here</a>
            <form action="<?php echo e(route("site.code.validate")); ?>" method="POST">
                <?php echo csrf_field(); ?>

            
            <div class="inputBox1">
                <input type="text text-light" name="code">
                <span class="user text-light">Email</span>

                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button type="submit" class="enter text-light mt-5">Enter</button>
        </form>
        </div>
    </div>
    </div>
</div>


    <?php $__env->startPush('js'); ?>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.includes.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\videoplatform\resources\views/frontend/home.blade.php ENDPATH**/ ?>