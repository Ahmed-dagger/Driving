

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageTitle'); ?>
    <?php echo e($pageTitle); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('dashboard.layouts.common._partial.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <form class="form" method="POST" action="<?php echo e(route("admin.create")); ?>">
        <?php echo csrf_field(); ?>
        <div class="card-body">
            <div class="form-group">
                <label>Full Name:</label>
                <input name="name" type="text" class="form-control form-control-solid" placeholder="Enter full name"/>
                <span class="form-text text-muted">Please enter your full name</span>
            </div>
            <div class="form-group">
                <label>Email address:</label>
                <input name="email" type="email" class="form-control form-control-solid" placeholder="Enter email"/>
                <span class="form-text text-muted">We'll never share your email with anyone else</span>
            </div>
            <div class="form-group">
                <label>Phone:</label>
                <input name="Phone" type="text" class="form-control form-control-solid" placeholder="Enter email"/>
                <span class="form-text text-muted">We'll never share your email with anyone else</span>
            </div>
            <div class="form-group">
                <label>Phone:</label>
                <input name="Phone" type="text" class="form-control form-control-solid" placeholder="Enter email"/>
                <span class="form-text text-muted">We'll never share your email with anyone else</span>
            </div>
            <div class="form-group">
                <label>status:</label>
                <div class="checkbox-list">
                    <label class="checkbox">
                        <input type="checkbox"/>
                        <span></span>
                        active
                    </label>
                    <label class="checkbox">
                        <input type="checkbox"/>
                        <span></span>
                        inactive
                    </label>
                </div>
            </div>
            <div class="form-group">
                <label>Admin Type:</label>
                <div class="checkbox-list">
                    <label class="checkbox">
                        <input type="checkbox"/>
                        <span></span>
                        Admin
                    </label>
                    <label class="checkbox">
                        <input type="checkbox"/>
                        <span></span>
                        Supervisor
                    </label>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <button type="reset" class="btn btn-primary mr-2">Submit</button>
            <button type="reset" class="btn btn-secondary">Cancel</button>
        </div>
    </form>



    <?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<link href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet">
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\newPLatform\resources\views/dashboard/admin/admins/create.blade.php ENDPATH**/ ?>