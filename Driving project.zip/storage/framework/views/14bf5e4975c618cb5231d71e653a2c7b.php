<div class="menu-item">
    <div class="pb-2 menu-content">
        <span class="menu-section text-muted text-uppercase fs-8 ls-1"><?php echo e(check_guard()->name); ?> Dashboard</span>
    </div>
</div>
<div class="menu-item">
    <a class="menu-link <?php echo e(request()->routeIS('admin.admins.index') ? 'active' : ''); ?>" href="<?php echo e(route('admin.admins.index')); ?>">
        <span class="menu-icon">
            <i class="bi bi-grid fs-3"></i>
        </span>
        <span class="menu-title"><?php echo e(trans('dashboard/admin.admins')); ?></span>
    </a>
</div>
<div class="menu-item">
    <a class="menu-link <?php echo e(request()->routeIS('admin.categories.index') ? 'active' : ''); ?>" href="<?php echo e(route('admin.categories.index')); ?>">
        <span class="menu-icon">
            <i class="bi bi-grid fs-3"></i>
        </span>
        <span class="menu-title"><?php echo e(trans('dashboard/admin.categories')); ?></span>
    </a>
</div>
<div class="menu-item">
    <a class="menu-link <?php echo e(request()->routeIS('admin.playlist.playlists.index') ? 'active' : ''); ?>" href="<?php echo e(route('admin.playlist.playlists.index')); ?>">
        <span class="menu-icon">
            <i class="bi bi-grid fs-3"></i>
        </span>
        <span class="menu-title"><?php echo e(trans('dashboard/admin.playlists')); ?></span>
    </a>
</div>
<div class="menu-item">
    <a class="menu-link <?php echo e(request()->routeIS('admin.courses.index') ? 'active' : ''); ?>" href="<?php echo e(route('admin.courses.index')); ?>">
        <span class="menu-icon">
            <i class="bi bi-grid fs-3"></i>
        </span>
        <span class="menu-title"><?php echo e(trans('dashboard/admin.courses')); ?></span>
    </a>
</div>

<div class="menu-item">
    <a class="menu-link <?php echo e(request()->routeIS('admin.videos.index') ? 'active' : ''); ?>" href="<?php echo e(route('admin.videos.index')); ?>">
        <span class="menu-icon">
            <i class="bi bi-grid fs-3"></i>
        </span>
        <span class="menu-title"><?php echo e(trans('dashboard/admin.videos')); ?></span>
    </a>
</div>


<div class="menu-item">
    <a class="menu-link <?php echo e(request()->routeIS('admin.settings') ? 'active' : ''); ?>" href="<?php echo e(route('admin.settings')); ?>">
        <span class="menu-icon">
            <i class="bi bi-grid fs-3"></i>
        </span>
        <span class="menu-title"><?php echo e(trans('dashboard/admin.settings')); ?></span>
    </a>
</div>

<div class="menu-item">
    <a class="menu-link <?php echo e(request()->routeIS('admin.teachers.index') ? 'active' : ''); ?>" href="<?php echo e(route('admin.teachers.index')); ?>">
        <span class="menu-icon">
            <i class="bi bi-grid fs-3"></i>
        </span>
        <span class="menu-title"><?php echo e(trans('dashboard/admin.teachers')); ?></span>
    </a>
</div>

<div class="menu-item">
    <a class="menu-link <?php echo e(request()->routeIS('admin.academics.index') ? 'active' : ''); ?>" href="<?php echo e(route('admin.academics.index')); ?>">
        <span class="menu-icon">
            <i class="bi bi-grid fs-3"></i>
        </span>
        <span class="menu-title"><?php echo e(trans('dashboard/admin.academics')); ?></span>
    </a>
</div>


<?php /**PATH E:\newPLatform\resources\views/dashboard/layouts/common/includes/sidebars/_admin.blade.php ENDPATH**/ ?>