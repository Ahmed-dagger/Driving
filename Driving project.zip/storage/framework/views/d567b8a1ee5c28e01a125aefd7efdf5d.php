<footer>
    
</footer><?php /**PATH D:\Driving project\resources\views/frontend/includes/common/_footer.blade.php ENDPATH**/ ?>