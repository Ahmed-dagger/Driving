

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageTitle'); ?>
    <?php echo e(trans('dashboard/admin.edit_package')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('dashboard.layouts.common._partial.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card">
        <form action="<?php echo e(route('admin.packages.update', $package->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group my-2">
                <label for="name"><?php echo e(trans('dashboard/admin.name')); ?></label>
                <input type="text" name="name" id="name" class="form-control" value="<?php echo e(old('name', $package->name)); ?>" required>
            </div>

            <div class="form-group my-2">
                <label for="description"><?php echo e(trans('dashboard/admin.description')); ?></label>
                <textarea name="description" id="description" class="form-control" rows="3"><?php echo e(old('description', $package->description)); ?></textarea>
            </div>

            <div class="form-group my-2">
                <label for="days_count"><?php echo e(trans('dashboard/admin.days_count')); ?></label>
                <input type="number" name="days_count" id="days_count" class="form-control" value="<?php echo e(old('days_count', $package->days_count)); ?>" required>
            </div>

            <div class="form-group my-2">
                <label for="hours_count"><?php echo e(trans('dashboard/admin.hours_count')); ?></label>
                <input type="number" name="hours_count" id="hours_count" class="form-control" value="<?php echo e(old('hours_count', $package->hours_count)); ?>" required>
            </div>

            <div class="form-group my-2">
                <label for="price"><?php echo e(trans('dashboard/admin.price')); ?></label>
                <input type="number" step="0.01" name="price" id="price" class="form-control" value="<?php echo e(old('price', $package->price)); ?>" required>
            </div>

            <button type="submit" class="btn btn-primary my-4"><?php echo e(trans('dashboard/general.update')); ?></button>
        </form>

        <?php if(session('success')): ?>
            <p style="color: green;"><?php echo e(session('success')); ?></p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Driving project\resources\views/dashboard/Admin/packages/edit.blade.php ENDPATH**/ ?>