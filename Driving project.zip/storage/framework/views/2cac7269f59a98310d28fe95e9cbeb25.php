

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageTitle'); ?>
    <?php echo e($pageTitle); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('dashboard.layouts.common._partial.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="card">
        <form action="<?php echo e(route('admin.learners.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="form-group my-2">
                <label for="name"><?php echo e(trans('dashboard/admin.name')); ?></label>
                <input type="text" name="name" id="name" class="form-control" required>
            </div>

            <div class="form-group my-2">
                <label for="email"><?php echo e(trans('dashboard/admin.email')); ?></label>
                <input type="email" name="email" id="email" class="form-control" required>
            </div>

            <div class="form-group my-2">
                <label for="password"><?php echo e(trans('dashboard/admin.password')); ?></label>
                <input type="password" name="password" id="password" class="form-control" required>
            </div>

            <div class="form-group my-2">
                <label for="phone"><?php echo e(trans('dashboard/admin.phone')); ?></label>
                <input type="text" name="phone" id="phone" class="form-control">
            </div>

            <div class="form-group my-2">
                <label for="status"><?php echo e(trans('dashboard/general.status')); ?></label>
                <select name="status" id="status" class="form-control" required>
                    <option value="active"><?php echo e(trans('dashboard/general.active')); ?></option>
                    <option value="inactive"><?php echo e(trans('dashboard/general.inactive')); ?></option>
                </select>
            </div>

            <div class="form-group my-2">
                <label for="bio"><?php echo e(trans('dashboard/admin.bio')); ?></label>
                <textarea name="bio" id="bio" class="form-control" rows="3"></textarea>
            </div>

            <input type="hidden" name="user_type" value="learner">

            <button type="submit" class="btn btn-primary my-4"><?php echo e(trans('dashboard/general.save')); ?></button>
        </form>


        <?php if(session('success')): ?>
            <p style="color: green;"><?php echo e(session('success')); ?></p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Driving project\resources\views/dashboard/Admin/learners/create.blade.php ENDPATH**/ ?>