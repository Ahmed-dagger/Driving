<!--begin::Footer-->
<div class="d-flex flex-center flex-column-auto p-10">
    <!--begin::Links-->
    <div class="d-flex align-items-center fw-bold fs-6">
        <a href="#" class="text-muted text-hover-primary px-2">About</a>
        <a href="#" class="text-muted text-hover-primary px-2">Contact</a>
        <a href="#" class="text-muted text-hover-primary px-2">Contact Us</a>
    </div>
    <!--end::Links-->
</div>
<!--end::Footer-->
<?php /**PATH E:\newPLatform\resources\views/dashboard/layouts/common/includes/login/_footer.blade.php ENDPATH**/ ?>