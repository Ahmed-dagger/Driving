
<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('pageTitle', $pageTitle); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid justify-content-center align-items-center SubHeader">
    <div class="container align-items-center justify-content-center">
        <div class="row justify-content-center align-items-center">
            <div class="container pt-5">
                <h3 class="text-center text-light py-4">Academies</h3>

            </div>
            <div class="container d-flex text-center justify-content-center pb-5">
                <a class="text-decoration-none" href="<?php echo e(route('site.home')); ?>">
                    <h5 class="text-light pr-1">Home </h5>
                </a>
                <h6 class="text-danger d-flex">🔴</h6>
                <a href="<?php echo e(route('site.academies')); ?>" class="text-decoration-none">
                    <h5 class="text-light pl-1">Academies</h5>
                </a>

            </div>


        </div>

    </div>

</div>


<div class="container-fluid TeamMembers">
    <div class="container justify-content-center d-flex my-4">
        <h2 class="text-center font-weight-bold my-5">Our Associated academies</h2>
    </div>
    <div class="container text-center justify-content-center text-center TeamMembers">
        <div class="row g-3 mb-4">
            
            <?php $__currentLoopData = $academies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $academy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-sm justify-content-center text-center">
                <a href="<?php echo e(route('site.academies.show', $academy->id )); ?>"><img class="rounded-circle img-fluid MembersImg" src="<?php echo e($academy->getdefImageUrl($academy-> name )); ?>" alt=""></a>
                <div class="container my-3">
                   <a class="text-decoration-none text-dark" href="<?php echo e(route('site.academies.show', $academy->id )); ?>"> <h5 class="text-dark text-center"><?php echo e($academy-> name); ?></h5></a>

                </div>

            </div>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>





<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.includes.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\newPLatform\resources\views/frontend/Academies.blade.php ENDPATH**/ ?>