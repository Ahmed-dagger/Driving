<div class="d-flex">

    <?php if(is_null($learner->deleted_at)): ?>
        
        <form id="delete-form-<?php echo e($learner->id); ?>" action="<?php echo e(route('admin.learners.destroy', $learner->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="btn btn-danger btn-sm mx-1"><?php echo e(trans('dashboard/general.delete')); ?></button>
        </form>
    <?php else: ?>
        
        <form action="<?php echo e(route('admin.learners.restore', $learner->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button class="btn btn-warning btn-sm mx-1"><?php echo e(trans('dashboard/general.restore')); ?></button>
        </form>
    <?php endif; ?>

    
    <a href="<?php echo e(route('admin.learners.edit', $learner->id)); ?>" class="btn btn-info btn-sm mx-1">
        <?php echo e(trans('dashboard/general.update')); ?>

    </a>

</div>



    <script>
        function deleteAdmin(id) {
            if (confirm("Are you sure you want to delete this admin?")) {
                document.getElementById('delete-form-' + id).submit();
            }
        }
    </script>

<?php /**PATH D:\Driving project\resources\views/dashboard/Admin/learners/btn/actions.blade.php ENDPATH**/ ?>