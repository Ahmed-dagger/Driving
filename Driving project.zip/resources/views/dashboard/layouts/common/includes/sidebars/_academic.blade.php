<div class="menu-item">
    <div class="menu-content pb-2">
        <span class="menu-section text-muted text-uppercase fs-8 ls-1">{{check_guard()->name}} Dashboard</span>
    </div>
</div>
<div class="menu-item">
    <a class="menu-link active" href="../../demo13/dist/index.html">
        <span class="menu-icon">
            <i class="bi bi-grid fs-3"></i>
        </span>
        <span class="menu-title">Default</span>
    </a>
</div>
<div class="menu-item">
    <a class="menu-link" href="../../demo13/dist/dashboards/only-header.html">
        <span class="menu-icon">
            <i class="bi bi-window fs-3"></i>
        </span>
        <span class="menu-title">Only Header</span>
    </a>
</div>
<div class="menu-item">
    <a class="menu-link" href="../../demo13/dist/landing.html">
        <span class="menu-icon">
            <i class="bi bi-app-indicator fs-3"></i>
        </span>
        <span class="menu-title">Landing Page</span>
    </a>
</div>
