        <!--end::Authentication - Sign-in-->
    </div>
    <!--end::Main-->
    <script>var hostUrl = "dashboard/assets/";</script>
    <!--begin::Javascript-->
    <!--begin::Global Javascript Bundle(used by all pages)-->
    <script src="{{ asset("dashboard/assets/plugins/global/plugins.bundle.js") }}"></script>
    <script src="{{ asset("dashboard/assets/js/scripts.bundle.js") }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
</body>
<!--end::Body-->
</html>
