@include('dashboard.layouts.common.includes.login._tpl_start')
@yield('content')
@include('dashboard.layouts.common.includes.login._footer')
@include('dashboard.layouts.common.includes.login._tpl_end')
