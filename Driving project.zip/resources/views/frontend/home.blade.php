@extends('frontend.includes.site')
@push('css')
@endpush
@section('pageTitle', $pageTitle)

@section('content')


<div class="container my-5">
    <div class="row justify-content-center text-center my-5">
<div class="container justify-content-center text-center">
    </div>
    </div>
</div>


    @push('js')
    @endpush
@endsection
