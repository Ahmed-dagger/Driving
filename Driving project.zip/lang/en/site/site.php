<?php
return [
    'home_page_title'                         =>                  'Home',
    'course_page_title'                         =>                  'Courses',
    'academy_page_title'                         =>                  'Academies',
    'About_page_title'                         =>                  'About',
    'Contact_page_title'                         =>                  'Contact',
    'Other_page_title'                         =>                  'Other',
    'Cart_page_title'                         =>                  'Cart',
    'content_page_title'                         =>                  'Course Content',
    'login'                         =>                  'Log in',
    'register'                         =>                  'Register',
];
