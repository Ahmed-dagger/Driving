<?php
return [
    'home_banner_title'                         =>                    'We have the best courses and trainings here',
    'home_banner_subtitle'                         =>                 'You will find here the best courses and training beacuse we have the best tutors enroll with us and enjoy the joyful of learning',
    'home_banner_video_button'                         =>             'Watch a video',
    'home_banner_start_button'                         =>             "Let's start",
    'home_banner_users_number'                         =>             "Active Users",
    'home_banner_Courses_number'                         =>           "Courses",
    'home_course_category_title1'                         =>           'All',
    'home_course_category_title2'                         =>          'from Subul Almaharat',
    'home_course_search'                         =>                   'Look for courses',
    'home_parteners_title'                         =>                   'All our Trusted Partners',
];