<?php
return [
    'main_dashboard'                     =>                  'Main Dashboard',
    'settings'                     =>                  'Settings',
];