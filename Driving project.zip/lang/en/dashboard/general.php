<?php
return [
    'status'      => 'Status',
    'created_at'  => 'Created At',
    'updated_at'  => 'Updated At',
    'deleted_at'  => 'Deleted At',
    'actions'     => 'Actions',
    'delete'      => 'Delete',
    'restore'     => 'Restore',
    'update'      => 'Update',
    'active'      => 'Active',
    'inactive'    => 'Inactive',
    'save'        => 'Save',
];