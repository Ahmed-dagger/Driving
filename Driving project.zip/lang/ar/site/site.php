<?php
return [
    'home_page_title'                         =>                  'الرئيسية',
    'course_page_title'                         =>                  'الكورسات',
    'About_page_title'                         =>                  'عنا',
    'Contact_page_title'                         =>                  'التواصل',
    'Other_page_title'                         =>                  'اخرى',
    'Cart_page_title'                          =>                 'عربة التسوق',
    'login'                         =>                  'تسيجل الدخول',
    'register'                         =>                  'التسجيل',


];
