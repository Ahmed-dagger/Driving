<?php
return [
    'fullname'                       =>                  ' الاسم كامل ',
    'teachers'                         =>                  'المشرف',
    'email'                        =>                  'البريد الالكترونــى',
    'categories'                        =>                  'الفئات',
    'playlists'                        =>                  'القوائم',
    'desc'                             =>                       'الوصف',
    'courses'                             =>                       'الكورسات',
    'price'                             =>                       'السعر',
];
