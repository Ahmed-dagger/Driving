<?php
return [
    'admins'                       =>                  'المديرين و المشرفين',
    'name'                         =>                  'الاســم',
    'email'                        =>                  'البريد الالكترونــى',
    'categories'                        =>                  'الفئات',
    'playlists'                        =>                  'القوائم',
    'desc'                             =>                       'الوصف',
    'courses'                             =>                       'الكورسات',
    'price'                             =>                       'السعر',
    'playlist'                             =>                       'playlist',
];
