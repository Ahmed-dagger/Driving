<?php
return [
    'main_dashboard'                     =>                  'لوحة التحكم',
];