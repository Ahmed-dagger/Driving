<?php
return [
    'status'                         =>                  'الحالــه',
    'created_at'                     =>                  'تم الانشاء',
    'updated_at'                     =>                  'تم التحديث',
    'deleted_at'                     =>                  'تم الحذف',
    'actions'                        =>                  'الاجــرائات',
    'delete'                        =>                  'حذف',
    'restore'                        =>                  'استعادة',
    'update'                        =>                  'تحديث',
];
