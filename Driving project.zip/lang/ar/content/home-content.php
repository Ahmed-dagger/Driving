<?php
return [
    'home_banner_title'                         =>                  'نوفر لك مكتبة متكاملة من الكورسات و التدريبات',
    'home_banner_subtitle'                         =>                  'ستجد هنا أفضل الدورات التدريبية لأن لدينا أفضل المعلمين. انضم إلينا واستمتع بفرحة التعلم.',
    'home_banner_video_button'                         =>                  'لنبدأ',
    'home_banner_start_button'                         =>                  'شاهد الفيديو',
    'home_banner_users_number'                         =>                  "المستخدمين المتفاعلين",
    'home_banner_Courses_number'                         =>                  "الكورسات المتوفرة",
    'home_course_category_title1'                         =>                  'كل',
    'home_course_category_title2'                         =>                  '  من سبل المهارات',
    'home_course_search'                         =>                  'ابحث عن الكورسات',
    'home_parteners_title'                         =>                   'شركائنا الموثوقين',
];
